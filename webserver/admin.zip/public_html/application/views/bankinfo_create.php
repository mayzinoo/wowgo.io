<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mid_top_padding">
    <div class="breadcome-list">
        <div class="row">
<div class="col-md-12 bankinfo">
<?=form_open('Admin/bankinfo_insert/')?>
    <h5 class="small_bottom_padding">Fill the bank information</h5>
    <div class="col-md-2 small_padding">
        <label>Bank Info</label>
    </div>
    <div class="col-md-10 small_padding">
        <input type="text" name="bankname" class="form-control" placeholder="bank name">
    </div>
    <div class="col-md-2 small_padding">
        <label>Account Owner</label>
    </div>
    <div class="col-md-10 small_padding">
        <input type="text" name="name" class="form-control" placeholder="ower name"> 
    </div>
   		<div class="col-md-2 small_padding">
        	<label>Account Number</label>
   		</div>
		<div class="col-md-10 small_padding">
	        <input type="text" name="acctno" class="form-control" placeholder="account number">
    		</div>
	<div class="col-md-10 col-md-offset-2">
<div class="right"><button type="submit" class="btn btn-success">Save</button></div>
	</div>
<?=form_close()?>
</div>
<div class="col-md-12 col-sm-12 col-xs-12 mid_top_padding bankinfo">
<h5 class="mid_bottom_padding">Bank Information List</h5>
	<table class="table">
		<tr>
			<th>Account Owner Name</th>
			<th>Bank Name</th>
			<th>Account Number</th>
		</tr>
		<tbody>
			<?php   
	foreach($bankinfolist->result() as $row):
  ?>
<tr>
	<td><?php echo $row->acctowner; ?></td>
	<td><?php echo $row->bankname; ?></td>
	<td><?php echo $row->acctno; ?></td>	
</tr>
<?php 
$i++;
endforeach; ?>
		</tbody>
	</table>
</div>
</div>
</div>
</div>
