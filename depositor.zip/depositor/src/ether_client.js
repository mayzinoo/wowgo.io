const assert = require('better-assert');
const ethers = require('ethers');
const Web3 = require('web3');
const lib = require('./lib');
const config = require('./config/config');

const web3 = new Web3(new Web3.providers.HttpProvider(config.ETHEREUM_PROVIDER));
const client = new ethers.providers.Web3Provider(web3.currentProvider);

function doGetTransactions(txIds, callback) {

    if (txIds.length === 0)
        return callback(null, []);

    var abort = false;
    var transactions = [];
    var count = 0;

    var batchRequest = new web3.BatchRequest();

    txIds.forEach(function(txId) {
        batchRequest.add(
            web3.eth.getTransaction.request(txId, function(err, transaction) {
                if (abort) return;

                if (err) {
                    abort = true;
                    return callback(err);
                }

                transactions.push(transaction);

                if (++count === txIds.length) {
                    return callback(null, transactions);
                }

                assert(count < txIds.length);
            })
        );
    });

    batchRequest.execute();

}

client.getTransactions = function(txIds, callback) {
    return lib.chunkRun(doGetTransactions, txIds, 3, 1, function(err, data) {

        if (err) {
            console.error('Error: when fetching', txIds.length, ' transactions, got error: ', err);
            return callback(err);
        }

        callback(null, data);
    });
};

client.getTransaction = function(transactionHash, callback) {
    client.getRawTransaction(transactionHash, 1, callback);
};

// returns [{address: amount}, ...])
function transactionsAddresses(transactions) {

    return transactions.map(function(transaction) {
        var addressToAmount = {};

        var address = transaction.to;
        if (!address) return;

        // Use wei to unit ratio 1 bit = how many wei
        var etherValue = web3.utils.fromWei(transaction.value, 'ether');
        var bitsValue = lib.ethersToBits(Number(etherValue));
        var value = bitsValue;
        
        assert(value >= 0);
        var oldAmount = addressToAmount[address] || 0;
        addressToAmount[address] = oldAmount + value;

        return addressToAmount;
        
    });
    
}

function doGetTransactionIdsAddresses(txids, callback) {
    doGetTransactions(txids, function(err, transactions) {
        if (err) return callback(err);

        callback(null, transactionsAddresses(transactions));
    });
}

// callback(err, listOfAddressToAmount
client.getTransactionIdsAddresses = function(txIds, callback) {
    // runs doGetTransactionIdsAddresses with chunks of 20 txIds, in parallel 2 at a time
    lib.chunkRun(doGetTransactionIdsAddresses, txIds, 20, 2, callback);
};

module.exports = client;