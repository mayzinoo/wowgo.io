var assert = require('better-assert');
var async = require('async');
var ethClient = require('./src/ether_client');
var database = require('./src/database');
var lib = require('./src/lib');
var fs = require('fs')
var logics = require('./logics');

// Mapping of deposit_address -> user_id
var depositAddresses = JSON.parse(fs.readFileSync('.addresses.json', 'utf8'));
assert(depositAddresses);


startBlockLoop();

function processTransactionIds(txids, callback) {

    ethClient.getTransactionIdsAddresses(txids, function(err, addressToAmountLists) {
        if (err) return callback(err);

        assert(txids.length === addressToAmountLists.length);

        var tasks = [];

        addressToAmountLists.forEach(function(addressToAmount, i) {

            var txid = txids[i];
            assert(txid);

            var usersToAmounts = {};
	console.log('addressToAmount',addressToAmount);

            // [{userId: amount}, ...]
        if(addressToAmount){
                Object.keys(addressToAmount).forEach(function(address) {

                    var userId = depositAddresses[address];
                    if (userId) {
                        usersToAmounts[userId] = addressToAmount[address];
                    }
                });
            }    
	console.log(usersToAmounts);
	console.log('usersToAmounts',usersToAmounts);


            if (Object.keys(usersToAmounts).length > 0) {
                console.log('Transactions: ', txid, ' matches: ', usersToAmounts);

                Object.keys(usersToAmounts).forEach(function(userId) {
                    tasks.push(function(callback) {
                        database.addDeposit(userId, txid, usersToAmounts[userId], callback);
                    });
                });
            }
        });

        async.parallelLimit(tasks, 3, callback);
    });
}



// Handling the block...


/// block chain loop

var lastBlockCount;
var lastBlockHash;

function startBlockLoop() {
    // initialize...
    database.getLastBlock(function (err, block) {
        if (err)
            throw new Error('Unable to get initial last block: ', err);

        console.log(block);
        lastBlockCount = block.height;
        lastBlockHash = block.hash;

        console.log('Initialized on block: ', lastBlockCount, ' with hash: ', lastBlockHash);

        blockLoop();
    });
}

function scheduleBlockLoop() {
    setTimeout(blockLoop, 20000);
}

function blockLoop() {
    ethClient.getBlock()
    .then(function(block) {

        if (block.number === lastBlockCount) {
            console.log('Block chain still ', block.number, ' length. No need to do anything');
            return scheduleBlockLoop();
        }


        ethClient.getBlock(lastBlockCount)
        .then(block => {
            if (lastBlockHash !== block.hash) {
                // There was a block-chain reshuffle. So let's just jump back a block
                database.getBlock(lastBlockCount - 1, function(err, block) {
                    if (err) {
                        console.error('ERROR: Unable jump back ', err);
                        return scheduleBlockLoop();
                    }

                    --lastBlockCount;

                    lastBlockHash = block.hash;
                    blockLoop();
                });
                return;
            }

            ethClient.getBlock(lastBlockCount+1)
            .then(block => {

                processBlock(block.hash, function(err) {
                    if (err) {
                        console.error('Unable to process block: ', block.hash, ' because: ', err);
                        return scheduleBlockLoop();
                    }

                    ++lastBlockCount;
                    lastBlockHash = block.hash;


                    database.insertBlock(lastBlockCount, lastBlockHash, function(err) {
                       if (err)
                          console.error('Danger, unable to save results in database...');

                        // All good! Loop immediately!
                        blockLoop();
                    });
                });
            })
            .catch(err => {
                console.error('Unable to get block hash: ', lastBlockCount+1);
                return scheduleBlockLoop();
            });
        })
        .catch(err => {
            console.error('Could not get block hash, error: ' + err);
            return scheduleBlockLoop();
        });
    })
    .catch(err => {
        console.error('Unable to get block count');
        return scheduleBlockLoop();
    });
}

function processBlock(hash, callback) {
    console.log('Processing block: ', hash);

    var start = new Date();

    ethClient.getBlock(hash).then(block => {
        console.log(block);
        var transactionsIds = block.transactions;   
        if(transactionsIds){

            processTransactionIds(transactionsIds, function(err) {
                if (err)
                    console.log('Unable to process block (in ',  (new Date() - start ) / 1000, ' seconds)');
                else
                    console.log('Processed ', transactionsIds.length, ' transactions in ', (new Date() - start ) / 1000, ' seconds');

                callback(err)
            });
        }
    })
    .catch(err => {
        console.error('Unable to get block info for: ', hash, ' got error: ', err);
        return callback(err);
    });

}

